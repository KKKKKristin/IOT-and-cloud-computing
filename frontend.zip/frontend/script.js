//for border change
var airTemContainer = document.getElementById("air_tem_container");
var airMoiContainer = document.getElementById("air_moi_container");
var soilMoiContainer = document.getElementById("soil_moi_container");
//for data change
var airTemValue = 25;
var airMoiValue = 50;
var soilMoiValue = 40;
var airTemValueDyn = document.getElementById("air_tem_value");
var airMoiValueDyn = document.getElementById("air_moi_value");
var SoilMoiValueDyn = document.getElementById("soil_moi_value");
//for db
var dynamicContentElement = document.getElementById("dynamicContent");
var detailInfoContent = document.getElementById("detail_content");
var plant_img = document.getElementById("plant_pic");
var SelectedOption = 1;
var currentDB; //store current option

// Initialization
document.addEventListener("DOMContentLoaded", function () {
  fetch("https://yhuang7214.github.io/ee542/plants.json")
    .then((response) => response.json())
    .then((data) => {
      // dynamicContentElement.innerHTML = "Selected Option: " + SelectedOption;
      displayDBData(data);
      currentDB = data;
      checkValue(currentDB);
    })
    .catch((error) => console.error("Error fetching plants JSON file:", error));

  // Get real-time data
  getRealTimeData();
});

//check real-time data every 5 seconds
setInterval(getRealTimeData, 5000);

// Listen DB option change
document.getElementById("plantOption").addEventListener("change", function () {
  SelectedOption = this.value;
  displayDBData(currentDB);
  checkValue(currentDB);
});

// Function to get real-time data
function getRealTimeData() {
  fetch("http://localhost:3100/")
    .then((response) => response.json())
    .then((data) => {
      // console.log(data);
      airTemValue = data?.air?.data?.temperature;
      airMoiValue = data?.air?.data?.humidity;
      soilMoiValue = Math.round(data?.soil?.data?.humidity * 100);
      // airMoiValue = parseFloat(data[0].data.humidity).toFixed(1);
      // console.log(airMoiValue);
      airTemValueDyn.innerHTML = `${airTemValue}`;
      airMoiValueDyn.innerHTML = `${airMoiValue}`;
      SoilMoiValueDyn.innerHTML = `${soilMoiValue}`;

      checkValue(currentDB);
    })
    .catch((error) => console.error("Error: Connect with flask.", error));
}

// Function to display selected plant data
function displayDBData(data) {
  detailInfoContent.innerHTML = `${data[SelectedOption].soil_humidity}`;
  var air_humidity_show = "null";
  if (data[SelectedOption].air_humidity_low != "null")
    air_humidity_show =
      data[SelectedOption].air_humidity_low +
      " - " +
      data[SelectedOption].air_humidity_high +
      " %";
  dynamicContentElement.innerHTML = `
  <p>Name: ${data[SelectedOption].name}</p>
  <table>
    <tr>
      <td>Air Temperature&nbsp;&nbsp;&nbsp;</td>
      <td>${data[SelectedOption].air_temp_low} - ${data[SelectedOption].air_temp_high} °C</td>
    </tr>
    <tr>
      <td>Air Humidity</td>
      <td>${air_humidity_show}</td>
    </tr>
    <tr>
      <td>Soil Humidity</td>
      <td>Prefers well-draining soil <br />with a value in the range of about 30 - 50 %</td>
    </tr>
  </table>
  `;
  plant_img.innerHTML = `
  <img src="${data[SelectedOption].img}" alt="${data[SelectedOption].name}">
  `;
}

// Function to check current value & change border color
function checkValue(data) {
  //air_tem
  if (
    airTemValue >= data[SelectedOption].air_temp_low &&
    airTemValue <= data[SelectedOption].air_temp_high
  ) {
    airTemContainer.style.border = "3px dotted green";
  } else airTemContainer.style.border = "3px dotted darkgoldenrod";
  //air_moi
  if (
    (airMoiValue >= data[SelectedOption].air_humidity_low &&
      airMoiValue <= data[SelectedOption].air_humidity_high) ||
    data[SelectedOption].air_humidity_low == "null"
  ) {
    airMoiContainer.style.border = "3px solid green";
  } else airMoiContainer.style.border = "3px solid darkgoldenrod";
  //soil_moi
  if (soilMoiValue >= 30 && soilMoiValue <= 50) {
    soilMoiContainer.style.border = "3px solid green";
  } else soilMoiContainer.style.border = "3px solid darkgoldenrod";
}
